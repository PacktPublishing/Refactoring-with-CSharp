﻿namespace Packt.CloudySkiesAir.Chapter12;

public class Program {
  public static void Main(string[] args) {
    Console.WriteLine("The program file has not been implemented yet");
  }
}
